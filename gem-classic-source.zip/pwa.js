/* Progressive enhancement: file:// mode already works offline without a service worker. */
(()=>{'use strict';
 let deferredInstall=null;
 const badge=document.createElement('button');badge.type='button';badge.id='gem-offline-status';
 badge.style.cssText='position:fixed;bottom:8px;left:8px;z-index:1000;font:12px Segoe UI,Arial,sans-serif;background:#102d50;color:white;border:1px solid #91a3bb;border-radius:8px;padding:6px 11px;opacity:.89;cursor:pointer;box-shadow:0 2px 7px #0002';
 const fileMode=location.protocol==='file:';
 const safeMode=location.protocol==='https:'||(['localhost','127.0.0.1'].includes(location.hostname));
 const set=(s)=>{badge.textContent=s};
 document.addEventListener('DOMContentLoaded',()=>{document.body.appendChild(badge);set(fileMode?'Offline HTML · Backup / حفظ احتياطي': 'Checking offline / فحص الأوفلاين')});
 const onClick=async()=>{
  if(deferredInstall){deferredInstall.prompt();deferredInstall=null;return}
  try {
    if(!window.GEM_OFFLINE)throw Error('Storage not initialized');
    const state=await window.GEM_OFFLINE.load();await window.GEM_OFFLINE.backup(state);
    if(typeof navigator.storage?.persist==='function')await navigator.storage.persist();
  } catch(e){alert('Backup failed / فشل النسخ الاحتياطي: '+e.message)}
 };
 badge.addEventListener('click',onClick);badge.title='Click to back up · Right-click for offline diagnostics';badge.addEventListener('contextmenu',e=>{e.preventDefault();location.href='offline-check.html'});
 window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;set('Install GEM App / تثبيت التطبيق')});
 if(safeMode&&'serviceWorker' in navigator){navigator.serviceWorker.register('./service-worker.js',{scope:'./'}).then(async()=>{
   await navigator.serviceWorker.ready;
   if(!deferredInstall)set('Offline shell ready · Backup / ملفات التشغيل جاهزة');
 }).catch(e=>set('HTML Offline · Backup / حفظ احتياطي'))}
 else if(!fileMode)set('Offline HTML · Backup / حفظ احتياطي');
 if('storage' in navigator && navigator.storage.persisted){navigator.storage.persisted().catch(()=>{})}
 window.addEventListener('online',()=>{if(!fileMode&&!deferredInstall)set('Offline Ready · Backup / أوفلاين جاهز')});
})();
