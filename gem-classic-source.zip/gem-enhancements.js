/* Local GEM enhancements: actual DOCX and 12K tiled viewport; no network dependencies. */
(()=>{'use strict';
 const tileSessions=new WeakMap();
 function installTiles(vp,stage,d,v){if(!d?.tileSet)return;
   const old=tileSessions.get(vp);if(old)old.stop();
   const set=d.tileSet, div=document.createElement('div');div.className='gem-tile-layer';div.setAttribute('aria-hidden','true');
   div.style.cssText=`position:absolute;left:0;top:0;width:${d.w}px;height:${d.h}px;pointer-events:none;z-index:1`;
   stage.insertBefore(div,stage.querySelector('svg.ann'));
   const tiles=[],size=set.size||1024;
   for(let y=0;y<d.h;y+=size)for(let x=0;x<d.w;x+=size){const el=document.createElement('div');el.className='gem-tile';const xx=x/size,yy=y/size;
     el.dataset.url=`${set.path}/t_${xx}_${yy}.jpg`;el.style.cssText=`position:absolute;left:${x}px;top:${y}px;width:${Math.min(size,d.w-x)}px;height:${Math.min(size,d.h-y)}px;overflow:hidden;`;
     div.appendChild(el);tiles.push(el)}
   let observer=null,active=false;
   const ioFactory=()=>new IntersectionObserver(entries=>{for(const e of entries){const el=e.target;if(e.isIntersecting){if(!el.firstElementChild){const img=new Image();img.alt='';img.decoding='async';img.loading='lazy';img.style.cssText='display:block;width:100%;height:100%;user-select:none;pointer-events:none';img.src=el.dataset.url;el.appendChild(img)}}else{el.replaceChildren()}}},{root:vp,rootMargin:'256px'});
   const update=(z)=>{const high=+z>0.20;
     if(high&&!active){active=true;observer=ioFactory();tiles.forEach(e=>observer.observe(e))}
     else if(!high&&active){active=false;observer.disconnect();observer=null;tiles.forEach(e=>e.replaceChildren())}
   };
   const session={update,stop(){observer?.disconnect();tiles.forEach(e=>e.replaceChildren());div.remove()}};
   tileSessions.set(vp,session);update(v.Z||0);
 }
 window.GEM_TILES={attach:installTiles,refresh(vp,z){tileSessions.get(vp)?.update(z)}};
 const esc=s=>String(s??'').replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
 const attrEsc=s=>esc(s).replace(/'/g,'&apos;');
 const download=(blob,name)=>{const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name.endsWith('.docx')?name:name.replace(/\.doc$/i,'')+'.docx';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),12000)};
 const b64bytes=s=>{const raw=atob(s),u=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)u[i]=raw.charCodeAt(i);return u};
 async function getImage(src){let bytes,type;if(src.startsWith('data:')){const match=/^data:([^;,]+);base64,(.*)$/s.exec(src);if(!match)throw Error('Unsupported image URI');type=match[1];bytes=b64bytes(match[2])}
 else{const r=await fetch(src);if(!r.ok)throw Error('Cannot read report image: '+src);type=r.headers.get('content-type')||'';bytes=new Uint8Array(await r.arrayBuffer())}
 if(type.includes('svg'))throw Error('SVG images must be converted to PNG for Word');
 if(type.includes('png'))return {bytes,type:'image/png',ext:'png'};
 if(type.includes('jpeg')||type.includes('jpg')||type.includes('jfif'))return {bytes,type:'image/jpeg',ext:'jpg'};
 throw Error('Unsupported Word image '+type)}
 const textPara=(s,style='Normal')=>`<w:p><w:pPr><w:pStyle w:val="${style}"/><w:bidi w:val="0"/></w:pPr><w:r><w:t xml:space="preserve">${esc(s)}</w:t></w:r></w:p>`;
 function imagePara(rId,n,cx,cy){return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${n}" name="Site Photo ${n}"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="${n}" name="Photo ${n}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${rId}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`}
 async function exportDOCX(html,name){if(typeof JSZip==='undefined')throw Error('DOCX library not loaded');const wrap=document.createElement('div');wrap.innerHTML=html;wrap.querySelectorAll('script,style,button,input,select').forEach(n=>n.remove());
  let paras=[],images=[],photoCards=[],rid=2,imgno=0;const candidates=[...wrap.querySelectorAll('h1,h2,h3,h4,p,li,tr,img,figcaption')];
  for(const e of candidates){if(e.tagName==='IMG'){
    const src=e.getAttribute('src');if(!src)continue;const im=await getImage(src);imgno++;const name='image'+imgno+'.'+im.ext;images.push({...im,name,rid:'rId'+rid});const maxw=5.7*914400,maxh=3.3*914400,ratio=(+e.getAttribute('width')||0)/(+e.getAttribute('height')||1);let rw=maxw,rh=maxh;if(Number.isFinite(ratio)&&ratio>0){if(ratio>maxw/maxh)rh=maxw/ratio;else rw=maxh*ratio}photoCards.push({rid:'rId'+rid,n:imgno,caption:(e.getAttribute('alt')||e.getAttribute('title')||e.parentElement?.textContent||'Site photo').trim().slice(0,100)});rid++;}
   else{let text=e.tagName==='TR'?[...e.children].map(x=>x.textContent.trim()).join('  |  '):e.textContent.trim();if(!text||text.length>2500)continue;
    // Prevent duplicated inline image alt/captions and oversize spans.
    if(e.querySelector('img'))continue;
    if(e.tagName==='H1'||e.tagName==='H2')paras.push(textPara(text,'Heading1'));
    else if(e.tagName==='H3'||e.tagName==='H4')paras.push(textPara(text,'Heading2'));
    else paras.push(textPara(text));}
  }
  if(!paras.length)paras=[textPara('Grand Egyptian Museum — Site Report','Heading1'),textPara(wrap.textContent.slice(0,10000))];
  if(photoCards.length){paras.push(textPara('Photo Appendix / ملحق الصور','Heading1'));
   for(let start=0;start<photoCards.length;start+=4){const chunk=photoCards.slice(start,start+4),rows=[];for(let row=0;row<2;row++){const cells=[];for(let col=0;col<2;col++){const card=chunk[row*2+col];cells.push('<w:tc><w:tcPr><w:tcW w:w=\"4500\" w:type=\"dxa\"/></w:tcPr>'+(card?imagePara(card.rid,card.n,Math.round(2.7*914400),Math.round(1.85*914400))+textPara(card.caption):'<w:p/>')+'</w:tc>')}rows.push('<w:tr>'+cells.join('')+'</w:tr>')}paras.push('<w:tbl><w:tblPr><w:tblW w:w=\"9000\" w:type=\"dxa\"/><w:tblBorders><w:bottom w:val=\"single\" w:sz=\"4\"/><w:top w:val=\"single\" w:sz=\"4\"/></w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w=\"4500\"/><w:gridCol w:w=\"4500\"/></w:tblGrid>'+rows.join('')+'</w:tbl>');if(start+4<photoCards.length)paras.push('<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>')}
  }
  const zip=new JSZip();
  const types=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">','<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>','<Default Extension="xml" ContentType="application/xml"/>','<Default Extension="jpg" ContentType="image/jpeg"/>','<Default Extension="png" ContentType="image/png"/>','<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>','<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>','</Types>'].join('');
  zip.file('[Content_Types].xml',types);
  zip.file('_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
  const rels=['<?xml version="1.0" encoding="UTF-8"?>','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">','<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'];
  images.forEach(im=>{zip.file('word/media/'+im.name,im.bytes);rels.push(`<Relationship Id="${im.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${im.name}"/>`)});zip.file('word/_rels/document.xml.rels',rels.join('')+'</Relationships>');
  zip.file('word/styles.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="20"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:rPr><w:b/><w:color w:val="183759"/><w:sz w:val="32"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:rPr><w:b/><w:sz w:val="25"/></w:rPr></w:style></w:styles>');
  const doc=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><w:body>${paras.join('')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="850" w:right="900" w:bottom="850" w:left="900"/></w:sectPr></w:body></w:document>`;
  zip.file('word/document.xml',doc);const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE'});download(blob,name);return {images:images.length,paragraphs:paras.length};
 }
 // Existing report buttons invoke this exported function. Report creation is asynchronous and errors are visible.
 window.GEM_EXPORT_WORD=(html,name)=>{exportDOCX(html,name).catch(err=>{alert('DOCX export failed / فشل تصدير Word: '+err.message);console.error(err)})};
 window.GEM_EXPORT_DOCX=exportDOCX;
})();
