/* GitHub Actions acceptance test. Uses a real Chromium browser and the locally bundled PDF.js engine. */
const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const assert=require('assert/strict');
const root=path.resolve(__dirname,'../dist');
function pdfFixture(){
 const stream='BT /F1 22 Tf 55 760 Td (GEM PIAZZA PDF TEST) Tj ET 30 30 530 740 re S';
 const objects=[
 '<< /Type /Catalog /Pages 2 0 R >>',
 '<< /Type /Pages /Kids [3 0 R 4 0 R] /Count 2 >>',
 '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 5 0 R /Resources << /Font << /F1 7 0 R >> >> >>',
 '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 6 0 R /Resources << /Font << /F1 7 0 R >> >> >>',
 `<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}\nendstream`,
 `<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}\nendstream`,
 '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
 let data='%PDF-1.4\n';const offsets=[0];
 for(let i=0;i<objects.length;i++){offsets.push(Buffer.byteLength(data));data+=`${i+1} 0 obj\n${objects[i]}\nendobj\n`}
 const start=Buffer.byteLength(data);data+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;
 for(let i=1;i<offsets.length;i++)data+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';
 data+=`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${start}\n%%EOF\n`;
 return Buffer.from(data,'ascii');
}
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.webmanifest':'application/manifest+json','.png':'image/png','.jpg':'image/jpeg','.pdf':'application/pdf'};
const server=http.createServer((req,res)=>{
 const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname),name=path.resolve(root,'.'+(pathname==='/'?'/index.html':pathname));
 if(!name.startsWith(root+path.sep)){res.writeHead(403).end();return}
 fs.readFile(name,(err,bytes)=>{if(err){res.writeHead(404).end('Not found');return}res.writeHead(200,{'Content-Type':mime[path.extname(name)]||'application/octet-stream','Cache-Control':'no-store'});res.end(bytes)})
});
(async()=>{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin=`http://127.0.0.1:${server.address().port}`;
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 try {
  const context=await browser.newContext({acceptDownloads:true});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(origin+'/index.html',{waitUntil:'load'});
  await page.waitForFunction(()=>!!window.GEM_OFFLINE&&!!document.querySelector('.head'));
  const before=await page.evaluate(async()=>await (await fetch('/api/state')).json());
  assert.equal(before.snags.length,0,'Hosted production app must start blank');
  assert.equal(before.drawings.length,0,'Public hosted build must not expose GEM drawings');
  await page.locator('#fileDrawing').setInputFiles({name:'Piazza_2pages.pdf',mimeType:'application/pdf',buffer:pdfFixture()});
  await page.waitForFunction(async()=>{const s=await(await fetch('/api/state')).json();return s.drawings?.length===2},null,{timeout:90000});
  const added=await page.evaluate(async()=>await(await fetch('/api/state')).json());
  assert.equal(added.drawings.length,2);
  assert.deepEqual(added.drawings.map(d=>d.pdfPage),[1,2]);
  for(const d of added.drawings){assert.ok(d.url.startsWith('data:image/png'));assert.ok(d.w>100&&d.h>100)}
  console.log('PASS PDF.js: 2 pages rasterized and stored with page numbers');
  await page.locator('[data-a="new"]').first().click();
  await page.locator('#f_de').fill('Acceptance test: PDF pin and photo');
  await page.locator('#addph').click();
  const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAIAAAAC64paAAAAHUlEQVR4nGP8//8/A7mAiWydo5pHNY9qHtVMFc0AnKADJXYG/XsAAAAASUVORK5CYII=','base64');
  await page.locator('#filePhoto').setInputFiles({name:'photo.png',mimeType:'image/png',buffer:png});
  await page.waitForFunction(()=>document.querySelectorAll('#modal .ph .p').length>0);
  await page.locator('#locb').click();
  await page.waitForSelector('#pimg');
  const im=await page.locator('#pimg').boundingBox();assert.ok(im&&im.width>20&&im.height>20);
  await page.mouse.click(im.x+im.width*0.5,im.y+im.height*0.5);
  await page.waitForFunction(()=>!document.querySelector('#pickok')?.disabled,null,{timeout:8000});
  await page.locator('#pickok').click();
  await page.locator('#sv').click();
  await page.waitForFunction(async()=>{const s=await(await fetch('/api/state')).json();return s.snags?.length===1&&s.snags[0].drawingId&&s.snags[0].photos?.length===1},null,{timeout:30000});
  console.log('PASS Snag: image, PDF pin, and issue persisted');
  const sw=await page.evaluate(async()=>{const r=await navigator.serviceWorker.ready;return !!r.active});
  assert.equal(sw,true,'Service Worker must be active');
  await context.setOffline(true);
  await page.reload({waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>!!document.querySelector('.head'));
  const offline=await page.evaluate(async()=>await (await fetch('/api/state')).json());
  assert.equal(offline.drawings.length,2);assert.equal(offline.snags.length,1);
  assert.ok(offline.snags[0].x>=0&&offline.snags[0].y>=0);
  console.log('PASS Offline: cold navigation while network disabled with all records intact');
  assert.deepEqual(errors,[],'No uncaught JavaScript errors');
  console.log('ALL E2E CHECKS PASS');
 }finally {await browser.close()}
})().catch(e=>{console.error('E2E FAILURE:',e);process.exitCode=1}).finally(()=>server.close());
