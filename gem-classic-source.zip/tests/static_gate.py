#!/usr/bin/env python3
"""Fail closed if site has personal/project media or lacks PDF.js."""
from pathlib import Path
import json,sys
r=Path(sys.argv[1]); required=['index.html','app.js','styles.css','service-worker.js','manifest.webmanifest','vendor/pdf.min.mjs','vendor/pdf.worker.min.mjs','vendor/jszip.min.js','offline-bridge.js','offline-check.html','BUILD_INFO.json']
missing=[x for x in required if not (r/x).is_file()]
if missing:raise SystemExit('Missing runtime assets: '+', '.join(missing))
if (r/'demo.html').exists() or (r/'tiles').exists() or (r/'project').exists():raise SystemExit('Project or demo files leaked into hosting output')
if any(x.suffix.lower() in {'.pdf','.dwg','.dxf','.xlsx','.docx'} for x in r.rglob('*') if x.is_file()):raise SystemExit('Project document leaked into public build')
seed=(r/'seed-data.js').read_text(encoding='utf-8')
if not all(x in seed for x in ['"snags": []','"drawings": []']):raise SystemExit('Production records not blank')
sw=(r/'service-worker.js').read_text(encoding='utf-8')
for x in ['vendor/pdf.min.mjs','vendor/pdf.worker.min.mjs']:
 if x not in sw:raise SystemExit('Offline cache does not cover '+x)
for x in ['pdf.min.mjs','pdf.worker.min.mjs']:
 if (r/'vendor'/x).stat().st_size<100000:raise SystemExit('Bundled PDF.js incomplete')
print('STATIC RELEASE GATE PASSED:',len([x for x in r.rglob('*') if x.is_file()]),'files')
