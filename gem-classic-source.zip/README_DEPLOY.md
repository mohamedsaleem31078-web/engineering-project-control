# GEM V6 Classic — release candidate (source only)

Do **not** publish any real project drawings, photos, demo cases, or schedules. This repository contains the **application shell only**. No EXE.

## Test and publish
- Push this source to branch `gem-classic-pwa-release`: workflow verifies static output and opens a real two-page PDF in Chromium, places and saves a pin+photo, then tests reload with networking disabled.
- Check GitHub Actions result. **Do not publish if any test fails**.
- After passing tests, merge verified source to `main` and enable Settings → Pages → GitHub Actions. `deploy` runs only from `main` and only after tests pass.
- Use Edge/Chrome to visit verified HTTPS Pages URL, install the PWA, import a PDF and test offline. No published pages URL is claimed in this kit.
- Note GitHub Pages may expose application source publicly even for a private code repository; never add project records or drawings.

Local `index.html` may work in browser as a fallback, **but service workers cannot register from `file://`**. For production the PWA must be served on HTTPS.

## Limitations
PDF.js remains a **CI-installed dependency**, not prebundled here; no local offline PDF conversion until the GitHub Action succeeds and publishes the bundled engine. Real Windows/Android/printer acceptance remains unverified.
