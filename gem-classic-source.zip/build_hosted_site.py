#!/usr/bin/env python3
"""Create privacy-safe static site, requiring a verified matching PDF.js pair."""
import json, pathlib, shutil, sys, re
src=pathlib.Path(__file__).resolve().parent
out=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else src/'dist')
if out.exists():shutil.rmtree(out)
out.mkdir(parents=True)
for name in ['index.html','styles.css','app.js','pwa.js','pdfjs-adapter.js','offline-bridge.js','browser-export.js','gem-enhancements.js','offline-check.html','manifest.webmanifest','schedule.json']:
    shutil.copy2(src/name,out/name)
(out/'assets').mkdir()
for name in ['logo_gem.png','logo_hill.png','app-192.png','app-512.png']:
    shutil.copy2(src/'assets'/name,out/'assets'/name)
(out/'vendor').mkdir()
shutil.copy2(src/'vendor/jszip.min.js',out/'vendor/jszip.min.js')
for name in ['pdf.min.mjs','pdf.worker.min.mjs']:
    p=src/'vendor'/name
    if not p.is_file() or p.stat().st_size < 100000:raise SystemExit(f'REQUIRED bundled Mozilla PDF.js missing: {p} (run npm install in build workflow)')
    shutil.copy2(p,out/'vendor'/name)
# Never publish demo records, actual plans, project timelines or 12K image tiles.
# Force a blank production database even on first run.
blank={'drawings':[],'snags':[],'dailyLogs':[],'captures':[],'locations':['Piazza','Recreation Garden','Sculpture Garden','Grand Staircase','Main Hall','Entrance Plaza','External Works'],'n':0,'history':[],'prog':{},'settings':{'company':'GEM Construction Management','lang':'both','demo':False}}
(out/'seed-data.js').write_text('window.GEM_SEED_STATE='+json.dumps(blank,ensure_ascii=False)+';\n',encoding='utf8')
(out/'seed-media.js').write_text('/* Hosted edition: user media remain private in browser IndexedDB. */\n',encoding='utf8')
(out/'schedule.json').write_text('{"rows":[]}\n',encoding='utf8')
# Preserve original app entry but don't publish demo.html (file not linked from published shell).
(out/'.nojekyll').write_text('',encoding='utf8')
# Service Worker shell must not include private drawings/assets absent in the hosted site.
sw=(src/'service-worker.js').read_text(encoding='utf8')
required=['index.html','styles.css','app.js','pwa.js','pdfjs-adapter.js','offline-bridge.js','browser-export.js','gem-enhancements.js','offline-check.html','manifest.webmanifest','seed-data.js','seed-media.js','vendor/jszip.min.js','vendor/pdf.min.mjs','vendor/pdf.worker.min.mjs','schedule.json','assets/logo_gem.png','assets/logo_hill.png','assets/app-192.png','assets/app-512.png']
sw=sw.replace("const CACHE_NAME='gem-classic-offline-v5';","const CACHE_NAME='gem-classic-offline-hosted-v1';")
sw=re.sub(r'const ASSETS=\[.*?\];', 'const ASSETS='+json.dumps(required)+';',sw,count=1,flags=re.S)
sw=re.sub(r"const core=\[.*?\];",'const core='+json.dumps(required)+';',sw,count=1,flags=re.S)
(out/'service-worker.js').write_text(sw,encoding='utf8')
# Offline checker needs to check the PDF engine, not proprietary project drawings.
p=out/'offline-check.html';s=p.read_text(encoding='utf8').replace("'project/files/Piazza_Ticketing_Plaza_Original.jpg'","'vendor/pdf.min.mjs','vendor/pdf.worker.min.mjs'")
s=re.sub(r"report\.appShell=!report\.missing\.some\(.*?\);", "report.appShell=report.missing.length===0;", s)
p.write_text(s,encoding='utf8')
# Build metadata and supply-chain provenance
(out/'BUILD_INFO.json').write_text(json.dumps({'product':'GEM V6 Classic','edition':'Hosted Offline PWA','demoDataIncluded':False,'userDrawingsIncluded':False,'pdfjsVersion':'4.10.38','pdfjsOrigin':'pdfjs-dist via npm in GitHub Actions'},indent=2),encoding='utf8')
print('Built privacy-safe PWA:',out,'files',len(list(out.rglob('*'))))
