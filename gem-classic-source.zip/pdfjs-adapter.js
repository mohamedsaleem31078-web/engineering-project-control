/* Offline Mozilla PDF.js adapter. Both matching files are embedded at deployment build. */
(()=>{'use strict';let promise=null;
 const load=async()=>{
  if(window.pdfjsLib?.getDocument)return window.pdfjsLib;
  let mod;
  try {mod=await import('./vendor/pdf.min.mjs')}
  catch(e){throw Error('PDF.js unavailable locally. Complete HTTPS build/deployment first. Details: '+(e?.message||e))}
  if(!mod?.getDocument||!mod?.GlobalWorkerOptions)throw Error('Unsupported PDF.js module');
  mod.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdf.worker.min.mjs',location.href).href;
  window.pdfjsLib=mod;return mod;
 };
 window.GEM_PDFJS={load:()=>promise||(promise=load().catch(e=>{promise=null;throw e})),available:()=>!!window.pdfjsLib?.getDocument};
})();
