/* GEM V6 isolated offline persistence; no EXE, no server. */
(()=>{'use strict';
const demo=window.GEM_FORCE_DEMO===true||/\/demo\.html$/i.test(location.pathname);
const DB=demo?'GEM_CLASSIC_DEMO_V2':'GEM_CLASSIC_PRODUCTION_V2';
let db;
const baseFetch=window.fetch.bind(window);
const response=(body,status=200,ct='application/json')=>new Response(typeof body==='string'?body:JSON.stringify(body),{status,headers:{'Content-Type':ct}});
const clone=o=>JSON.parse(JSON.stringify(o));
function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open(DB,2);r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains('kv'))db.createObjectStore('kv')};r.onsuccess=()=>{db=r.result;res()};r.onerror=()=>rej(r.error)})}
const get=k=>new Promise((res,rej)=>{const r=db.transaction('kv','readonly').objectStore('kv').get(k);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
const put=(k,v)=>new Promise((res,rej)=>{const t=db.transaction('kv','readwrite');t.objectStore('kv').put(v,k);t.oncomplete=()=>res();t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error)});
const toData=blob=>new Promise((res,rej)=>{const r=new FileReader;r.onload=()=>res(r.result);r.onerror=()=>rej(r.error);r.readAsDataURL(blob)});
function download(blob,name){const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),10000)}
function seed(){const s=clone(window.GEM_SEED_STATE||{});const cv=u=>typeof u==='string'&&u.startsWith('files/')?'project/'+u:u;
 for(const d of s.drawings||[]){d.url=cv(d.url);if(d.sourcePDF)d.sourcePDF=cv(d.sourcePDF)}
 for(const issue of [...(s.snags||[]),...(s.dailyLogs||[]),...(s.captures||[])])for(const ph of issue.photos||[])ph.url=cv(ph.url);
 if(!demo){s.snags=[];s.dailyLogs=[];s.captures=[];s.n=0;s.prog={};s.history=[];s.settings={...(s.settings||{}),demo:false};s.drawings=(s.drawings||[]).filter(d=>String(d.id).includes('PIAZZA')).slice(0,1);}
 else s.settings={...(s.settings||{}),demo:true};
 return s;
}
const visitMedia=(state,visit)=>{
 for(const d of state.drawings||[]){visit(d,'url');visit(d,'sourcePDF');visit(d,'originalUrl')}
 for(const r of [...(state.snags||[]),...(state.dailyLogs||[]),...(state.captures||[])])for(const ph of r.photos||[]){visit(ph,'url');visit(ph,'orig')}
 for(const k of ['logoL','logoR'])visit(state.settings||{},k);
};
function dataBlob(uri){const a=uri.split(','),meta=a[0].split(';')[0].slice(5)||'application/octet-stream';const bytes=atob(a.slice(1).join(',')),data=new Uint8Array(bytes.length);for(let i=0;i<bytes.length;i++)data[i]=bytes.charCodeAt(i);return new Blob([data],{type:meta})}
function ext(type){return (type||'').includes('pdf')?'pdf':(type||'').includes('png')?'png':(type||'').includes('svg')?'svg':(type||'').includes('webp')?'webp':'jpg'}
const offline={isDemo:demo,dbName:DB,initial:null,ready:null,schedule:window.GEM_SCHEDULE||{rows:[]},
 async load(){return await get('state')||clone(this.initial)},async save(s){if(!s||!Array.isArray(s.snags)||!Array.isArray(s.drawings))throw Error('Invalid project state');try{await put('state',s)}catch(e){throw Error('Browser storage failed or quota exceeded. Export a backup and free browser storage: '+(e?.message||e))}return true},
 async diagnostics(){const s=await this.load();let quota=null;try{if(navigator.storage?.estimate)quota=await navigator.storage.estimate()}catch{}let missing=[];visitMedia(s,(o,k)=>{if(o[k]&&typeof o[k]!=='string')missing.push(k)});return {data_dir:'IndexedDB / '+DB,state_exists:true,writable:true,issues:s.snags.length,drawings:s.drawings.length,missing_count:missing.length,missing_files:missing,storage_usage:quota?.usage||0,storage_quota:quota?.quota||0}},
 async backup(s){if(typeof JSZip==='undefined')throw Error('ZIP engine is missing');s=clone(s||await this.load());const zip=new JSZip(),refs=new Map(),missing=[];let seq=0;
 const media=[];visitMedia(s,(obj,key)=>{const u=obj[key];if(typeof u==='string'&&u&&!u.startsWith('blob:')&&!u.startsWith('backup-assets/'))media.push([obj,key,u])});
 for(const [obj,key,url] of media){if(refs.has(url)){obj[key]=refs.get(url);continue}
  try{let blob;if(url.startsWith('data:'))blob=dataBlob(url);else {const r=await baseFetch(url);if(!r.ok)throw Error('HTTP '+r.status);blob=await r.blob()}
   const file='backup-assets/asset_'+String(++seq).padStart(4,'0')+'.'+ext(blob.type);zip.file(file,blob);refs.set(url,file);obj[key]=file;
  }catch(e){missing.push(url+' ('+e.message+')');}
 }
 // Never silently claim a full, portable backup when bundled media was inaccessible.
 if(missing.length)throw Error('Cannot include '+missing.length+' bundled files in a portable backup. Open as installed PWA on localhost/HTTPS or attach original media. First: '+missing[0]);
 zip.file('state.json',JSON.stringify(s));zip.file('manifest.json',JSON.stringify({format:'GEM_V6_PORTABLE_ZIP_V2',version:2,mode:demo?'DEMO':'PRODUCTION',exportedAt:new Date().toISOString(),media:refs.size,issues:s.snags.length,drawings:s.drawings.length},null,2));
 const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:2}});download(blob,'GEM_'+(demo?'DEMO':'PROJECT')+'_BACKUP_'+new Date().toISOString().slice(0,10)+'.zip');return true;
 },
 async restore(file){if(typeof JSZip==='undefined')throw Error('ZIP engine is missing');if(file.size>400*1024*1024)throw Error('Backup exceeds 400 MB');const z=await JSZip.loadAsync(file);const manifest=JSON.parse(await z.file('manifest.json')?.async('string')||'null');if(!manifest||manifest.format!=='GEM_V6_PORTABLE_ZIP_V2')throw Error('Not a portable GEM backup');if(manifest.mode!==(demo?'DEMO':'PRODUCTION'))throw Error('Demo and production projects cannot be mixed');const s=JSON.parse(await z.file('state.json')?.async('string')||'null');if(!s||!Array.isArray(s.snags)||!Array.isArray(s.drawings))throw Error('Invalid backup state');const urls=new Map(),paths=[];visitMedia(s,(o,k)=>{if(typeof o[k]==='string'&&o[k].startsWith('backup-assets/'))paths.push([o,k,o[k]])});
 for(const [obj,key,path] of paths){let url=urls.get(path);if(!url){const f=z.file(path);if(!f)throw Error('Missing archived media: '+path);const data=await f.async('base64');url='data:'+(path.endsWith('.pdf')?'application/pdf':path.endsWith('.png')?'image/png':path.endsWith('.svg')?'image/svg+xml':path.endsWith('.webp')?'image/webp':'image/jpeg')+';base64,'+data;urls.set(path,url)}obj[key]=url}
 // All validations and file reads finish BEFORE replacing the active database.
 const ids=new Set();for(const issue of s.snags){if(!issue.id||ids.has(issue.id))throw Error('Backup has missing or duplicate issue IDs');ids.add(issue.id)}
 await this.save(s);return true;
 },
 async importPDF(file){if(file.size>60*1024*1024)throw Error('PDF exceeds 60 MB');
  const pdfjsLib=await window.GEM_PDFJS.load();
  const source=await toData(file);const data=new Uint8Array(await file.arrayBuffer());const pdf=await pdfjsLib.getDocument({data}).promise;
  if(pdf.numPages>40)throw Error('PDF exceeds 40 pages');const result=[];
  for(let n=1;n<=pdf.numPages;n++){const page=await pdf.getPage(n),v=page.getViewport({scale:1}),scale=Math.min(4,8192/Math.max(v.width,v.height),Math.sqrt(24000000/(v.width*v.height))),vp=page.getViewport({scale});
   const canvas=document.createElement('canvas');canvas.width=Math.ceil(vp.width);canvas.height=Math.ceil(vp.height);const ctx=canvas.getContext('2d',{alpha:false});await page.render({canvasContext:ctx,viewport:vp}).promise;
   const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('Canvas export failed')),'image/png'));
   result.push({name:file.name.replace(/\.pdf$/i,'')+' - Page '+n,url:await toData(blob),w:canvas.width,h:canvas.height,sourcePDF:n===1?source:null,pdfPage:n,pdfTotal:pdf.numPages});canvas.width=canvas.height=1;
  }return result;
 },download
};
offline.ready=openDB().then(async()=>{offline.initial=seed();return offline.load()});window.GEM_OFFLINE=offline;
window.fetch=async(input,init={})=>{const path=String(typeof input==='string'?input:input.url);if(path==='schedule.json')return response(offline.schedule||{rows:[]});if(!path.startsWith('/api/'))return baseFetch(input,init);await offline.ready;
 try{if(path.startsWith('/api/token'))return response('offline',200,'text/plain');
 if(path.startsWith('/api/state')){if(init.method==='PUT'){await offline.save(JSON.parse(init.body));return response({ok:true})}return response(await offline.load())}
 if(path.startsWith('/api/upload')){const b=init.body;if(!b?.size)throw Error('Empty upload');if(b.size>65*1024*1024)return response('Maximum 65 MB',413,'text/plain');return response({url:await toData(b)})}
 if(path.startsWith('/api/import.pdf'))return response(await offline.importPDF(init.body));
 if(path.startsWith('/api/info'))return response({dir:DB,files:0,state:true});
 if(path.startsWith('/api/diagnostics'))return response(await offline.diagnostics());
 if(path.startsWith('/api/health'))return response({ok:true});
 if(path.startsWith('/api/audit'))return response({passed:true,note:'Structural check only'});
 if(path.startsWith('/api/files'))return response([]);if(path.startsWith('/api/shutdown'))return response({ok:true});
 return response('Unavailable in browser offline edition',501,'text/plain');
 }catch(err){return response(String(err.message||err),500,'text/plain')}};
})();