GEM Classic Offline PWA. See DEPLOY_AR.md. WARNING: no real project documents should be committed to a public repo.
